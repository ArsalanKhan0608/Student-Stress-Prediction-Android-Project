//
// Created by Ashraf Khan on 05/Aug/2017.
//

#ifndef VOKATURIANDROID_THING_H
#define VOKATURIANDROID_THING_H

#ifdef __cplusplus
extern "C" {
#endif


#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <math.h>


#define my  me ->
#define your  you ->
#define our  us ->

#define strequ  ! strcmp
#define strnequ  ! strncmp

#ifdef __cplusplus
}
#endif

#endif //VOKATURIANDROID_THING_H
