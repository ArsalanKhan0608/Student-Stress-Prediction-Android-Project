package com.example.studentstressprediction;


import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class text extends AppCompatActivity {
    String TAG = "wsap";
    Button buttonAnalyzeMsg;
    Button buttonMoodEntry;
    Button button3;

    public void init(){
        buttonAnalyzeMsg = (Button)findViewById(R.id.buttonAnalyzeMsg);
        buttonAnalyzeMsg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent tie = new Intent(WelcomeScreen_Act.this,ContactSelect_Act.class);
                Intent tie = new Intent(text.this,SearchSmsAct.class);
                startActivity(tie);
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);

            }
        });
    }
    public void init2(){
        buttonMoodEntry = (Button)findViewById(R.id.button2);
        buttonMoodEntry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: wsap");
                Intent tie = new Intent(text.this,MoodEntry_Act.class);
                startActivity(tie);
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);

            }
        });
    }
    public void init3(){
        button3 = (Button)findViewById(R.id.button3);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent tie = new Intent(text.this, Timeline_Act.class);
                startActivity(tie);
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);

            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_text);
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();
        init();
        init2();
        init3();
    }

}
