package com.example.studentstressprediction;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.transition.Slide;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

public class Main2Activity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener , SensorEventListener {
    DrawerLayout drawerLayout;
    NavigationView navigationView;
    Toolbar toolbar;
    Sensor sensor;
    SensorManager sensorManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       //setContentView(R.layout.activity_main2);
        setContentView(R.layout.navigationbar);
        drawerLayout=findViewById(R.id.drawerlayout);
        navigationView=findViewById(R.id.nav_view);
        toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        navigationView.bringToFront();
        ActionBarDrawerToggle toggle= new ActionBarDrawerToggle(this,drawerLayout,R.string.navigationdraweropen,R.string.navigationdrawerclose);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setCheckedItem(R.id.settings);
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        sensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

    }
    @Override
public void onBackPressed(){
        if(drawerLayout.isDrawerOpen(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START);
        }
        else{
            super.onBackPressed();
        }
}
@Override
public boolean onNavigationItemSelected(MenuItem menuItem){
        switch (menuItem.getItemId()){
            case R.id.settings:
            {




                break;}
            case R.id.update: {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://play.google.com/store/apps"));
                startActivity(intent);
                break;
            }
            case R.id.share:
            {
                Intent intent1=new Intent(Intent.ACTION_SEND);
                startActivity(Intent.createChooser(intent1,"Send to"));
                break;
            }
            case R.id.about:
                Toast.makeText(this,"Share",Toast.LENGTH_SHORT).show();
                break;
            case R.id.email: {
                String myemail = "arsalankhan0608@gmail.com";
                Intent intent1 = new Intent(Intent.ACTION_SEND);
                intent1.putExtra(Intent.EXTRA_EMAIL, myemail);
                intent1.setType("message/rfc822");
                startActivity(Intent.createChooser(intent1, "Email"));
                break;
            }
            case R.id.email1:
            {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://m.facebook.com/arsalan.niazi.3720?ref=bookmarks"));
                startActivity(intent);
                break;
            }

        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
}
    @Override
    public void onResume() {
        super.onResume();
        sensorManager.registerListener(this, sensor, sensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    public void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    float xOld = 0;
    float yOld = 0;
    float zOld = 0;
    float Threshold = 1000;
    long OldTime = 0;

    @Override
    public void onSensorChanged(SensorEvent event) {
        float x = event.values[0];
        float y = event.values[1];
        float z = event.values[2];
        long CurrentTime = System.currentTimeMillis();
        if ((CurrentTime - OldTime) > 100) {
            long TimeDiff = CurrentTime - OldTime;
            OldTime = CurrentTime;
            float speed = Math.abs(x + y + z - xOld - yOld - zOld) / TimeDiff * 10000;
            if (speed > Threshold) {
                Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                v.vibrate(500);
                Toast.makeText(getApplicationContext(), "You seem stressed", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    public void TCamera(View view) {
        Intent intent=new Intent(Main2Activity.this,Camerra.class);
        startActivity(intent);

    }


    public void T_HRV(View view) {
        Intent intent=new Intent(Main2Activity.this,HRV.class);
        startActivity(intent);
    }

    public void TText(View view) {
        Intent intent=new Intent(Main2Activity.this,text.class);
        startActivity(intent);
    }

    public void TVoice(View view) {
        Intent intent=new Intent(Main2Activity.this,speech.class);
        startActivity(intent);
    }
}
